ALTER TABLE "companies" ENABLE ROW LEVEL SECURITY;
--> statement-breakpoint
ALTER TABLE "users" ENABLE ROW LEVEL SECURITY;
--> statement-breakpoint
ALTER TABLE "clients" ENABLE ROW LEVEL SECURITY;
--> statement-breakpoint
ALTER TABLE "invites" ENABLE ROW LEVEL SECURITY;
--> statement-breakpoint
ALTER TABLE "workflow_templates" ENABLE ROW LEVEL SECURITY;
--> statement-breakpoint
ALTER TABLE "projects" ENABLE ROW LEVEL SECURITY;
--> statement-breakpoint
ALTER TABLE "project_members" ENABLE ROW LEVEL SECURITY;
--> statement-breakpoint
ALTER TABLE "milestones" ENABLE ROW LEVEL SECURITY;
--> statement-breakpoint
ALTER TABLE "tasks" ENABLE ROW LEVEL SECURITY;
--> statement-breakpoint
ALTER TABLE "task_assignees" ENABLE ROW LEVEL SECURITY;
--> statement-breakpoint
ALTER TABLE "task_followers" ENABLE ROW LEVEL SECURITY;
--> statement-breakpoint
ALTER TABLE "task_dependencies" ENABLE ROW LEVEL SECURITY;
--> statement-breakpoint
ALTER TABLE "comments" ENABLE ROW LEVEL SECURITY;
--> statement-breakpoint
ALTER TABLE "approvals" ENABLE ROW LEVEL SECURITY;
--> statement-breakpoint
ALTER TABLE "time_entries" ENABLE ROW LEVEL SECURITY;
--> statement-breakpoint
ALTER TABLE "attendance" ENABLE ROW LEVEL SECURITY;
--> statement-breakpoint
ALTER TABLE "leaves" ENABLE ROW LEVEL SECURITY;
--> statement-breakpoint
ALTER TABLE "files" ENABLE ROW LEVEL SECURITY;
--> statement-breakpoint
ALTER TABLE "notifications" ENABLE ROW LEVEL SECURITY;
--> statement-breakpoint
ALTER TABLE "chat_threads" ENABLE ROW LEVEL SECURITY;
--> statement-breakpoint
ALTER TABLE "chat_messages" ENABLE ROW LEVEL SECURITY;
--> statement-breakpoint
ALTER TABLE "calendar_events" ENABLE ROW LEVEL SECURITY;
--> statement-breakpoint
ALTER TABLE "audit_logs" ENABLE ROW LEVEL SECURITY;
--> statement-breakpoint
ALTER TABLE "login_history" ENABLE ROW LEVEL SECURITY;
--> statement-breakpoint
CREATE POLICY "company_scope" ON "companies" USING ("id" = NULLIF(current_setting('app.current_company_id', true), '')::integer);
--> statement-breakpoint
CREATE POLICY "users_company_scope" ON "users" USING ("company_id" = NULLIF(current_setting('app.current_company_id', true), '')::integer);
--> statement-breakpoint
CREATE POLICY "clients_company_scope" ON "clients" USING ("company_id" = NULLIF(current_setting('app.current_company_id', true), '')::integer);
--> statement-breakpoint
CREATE POLICY "invites_company_scope" ON "invites" USING ("company_id" = NULLIF(current_setting('app.current_company_id', true), '')::integer);
--> statement-breakpoint
CREATE POLICY "templates_company_scope" ON "workflow_templates" USING ("company_id" = NULLIF(current_setting('app.current_company_id', true), '')::integer);
--> statement-breakpoint
CREATE POLICY "projects_company_scope" ON "projects" USING ("company_id" = NULLIF(current_setting('app.current_company_id', true), '')::integer);
--> statement-breakpoint
CREATE POLICY "files_company_scope" ON "files" USING ("company_id" = NULLIF(current_setting('app.current_company_id', true), '')::integer);
--> statement-breakpoint
CREATE POLICY "threads_company_scope" ON "chat_threads" USING ("company_id" = NULLIF(current_setting('app.current_company_id', true), '')::integer);
--> statement-breakpoint
CREATE POLICY "events_company_scope" ON "calendar_events" USING ("company_id" = NULLIF(current_setting('app.current_company_id', true), '')::integer);
--> statement-breakpoint
CREATE POLICY "audit_company_scope" ON "audit_logs" USING ("company_id" = NULLIF(current_setting('app.current_company_id', true), '')::integer);
--> statement-breakpoint
CREATE POLICY "member_project_scope" ON "project_members" USING (EXISTS (SELECT 1 FROM "projects" WHERE "projects"."id" = "project_members"."project_id" AND "projects"."company_id" = NULLIF(current_setting('app.current_company_id', true), '')::integer));
--> statement-breakpoint
CREATE POLICY "milestone_project_scope" ON "milestones" USING (EXISTS (SELECT 1 FROM "projects" WHERE "projects"."id" = "milestones"."project_id" AND "projects"."company_id" = NULLIF(current_setting('app.current_company_id', true), '')::integer));
--> statement-breakpoint
CREATE POLICY "task_project_scope" ON "tasks" USING ("project_id" IS NULL OR EXISTS (SELECT 1 FROM "projects" WHERE "projects"."id" = "tasks"."project_id" AND "projects"."company_id" = NULLIF(current_setting('app.current_company_id', true), '')::integer));
--> statement-breakpoint
CREATE POLICY "task_assignee_scope" ON "task_assignees" USING (EXISTS (SELECT 1 FROM "tasks" LEFT JOIN "projects" ON "projects"."id" = "tasks"."project_id" WHERE "tasks"."id" = "task_assignees"."task_id" AND ("tasks"."project_id" IS NULL OR "projects"."company_id" = NULLIF(current_setting('app.current_company_id', true), '')::integer)));
--> statement-breakpoint
CREATE POLICY "task_follower_scope" ON "task_followers" USING (EXISTS (SELECT 1 FROM "tasks" LEFT JOIN "projects" ON "projects"."id" = "tasks"."project_id" WHERE "tasks"."id" = "task_followers"."task_id" AND ("tasks"."project_id" IS NULL OR "projects"."company_id" = NULLIF(current_setting('app.current_company_id', true), '')::integer)));
--> statement-breakpoint
CREATE POLICY "task_dependency_scope" ON "task_dependencies" USING (EXISTS (SELECT 1 FROM "tasks" LEFT JOIN "projects" ON "projects"."id" = "tasks"."project_id" WHERE "tasks"."id" = "task_dependencies"."task_id" AND ("tasks"."project_id" IS NULL OR "projects"."company_id" = NULLIF(current_setting('app.current_company_id', true), '')::integer)));
--> statement-breakpoint
CREATE POLICY "comments_scope" ON "comments" USING (("project_id" IS NULL OR EXISTS (SELECT 1 FROM "projects" WHERE "projects"."id" = "comments"."project_id" AND "projects"."company_id" = NULLIF(current_setting('app.current_company_id', true), '')::integer)) AND ("task_id" IS NULL OR EXISTS (SELECT 1 FROM "tasks" LEFT JOIN "projects" ON "projects"."id" = "tasks"."project_id" WHERE "tasks"."id" = "comments"."task_id" AND ("tasks"."project_id" IS NULL OR "projects"."company_id" = NULLIF(current_setting('app.current_company_id', true), '')::integer))));
--> statement-breakpoint
CREATE POLICY "approvals_scope" ON "approvals" USING ("project_id" IS NULL OR EXISTS (SELECT 1 FROM "projects" WHERE "projects"."id" = "approvals"."project_id" AND "projects"."company_id" = NULLIF(current_setting('app.current_company_id', true), '')::integer));
--> statement-breakpoint
CREATE POLICY "time_user_scope" ON "time_entries" USING ("user_id" = NULLIF(current_setting('app.current_user_id', true), '')::integer OR EXISTS (SELECT 1 FROM "users" WHERE "users"."id" = "time_entries"."user_id" AND "users"."company_id" = NULLIF(current_setting('app.current_company_id', true), '')::integer));
--> statement-breakpoint
CREATE POLICY "attendance_user_scope" ON "attendance" USING ("user_id" = NULLIF(current_setting('app.current_user_id', true), '')::integer OR EXISTS (SELECT 1 FROM "users" WHERE "users"."id" = "attendance"."user_id" AND "users"."company_id" = NULLIF(current_setting('app.current_company_id', true), '')::integer));
--> statement-breakpoint
CREATE POLICY "leave_user_scope" ON "leaves" USING ("user_id" = NULLIF(current_setting('app.current_user_id', true), '')::integer OR EXISTS (SELECT 1 FROM "users" WHERE "users"."id" = "leaves"."user_id" AND "users"."company_id" = NULLIF(current_setting('app.current_company_id', true), '')::integer));
--> statement-breakpoint
CREATE POLICY "notification_user_scope" ON "notifications" USING ("user_id" = NULLIF(current_setting('app.current_user_id', true), '')::integer);
--> statement-breakpoint
CREATE POLICY "message_thread_scope" ON "chat_messages" USING (EXISTS (SELECT 1 FROM "chat_threads" WHERE "chat_threads"."id" = "chat_messages"."thread_id" AND "chat_threads"."company_id" = NULLIF(current_setting('app.current_company_id', true), '')::integer));
--> statement-breakpoint
CREATE POLICY "login_user_scope" ON "login_history" USING ("user_id" = NULLIF(current_setting('app.current_user_id', true), '')::integer);
