import type { Config } from '@netlify/functions'
import { desc, eq } from 'drizzle-orm'
import { db } from '../../db/index.js'
import { clients, companies, projects, tasks, users, workflowTemplates } from '../../db/schema.js'

const json = (data: unknown, init?: ResponseInit) => Response.json(data, init)

const seedWorkspace = {
  demoAccounts: [
    { email: 'super.admin@agencyos.demo', role: 'super_admin' },
    { email: 'manager@agencyos.demo', role: 'project_manager' },
    { email: 'client@agencyos.demo', role: 'client' },
  ],
  permissions: {
    super_admin: ['*'],
    admin: ['manage_company', 'manage_users', 'manage_projects', 'view_reports'],
    project_manager: ['manage_projects', 'manage_tasks', 'approve_work', 'view_reports'],
    team_leader: ['manage_tasks', 'approve_work', 'view_team'],
    employee: ['manage_own_tasks', 'track_time', 'comment'],
    client: ['view_assigned_projects', 'approve_client_work', 'comment'],
  },
}

export default async function handler(request: Request) {
  const url = new URL(request.url)
  const resource = url.searchParams.get('resource') ?? 'dashboard'

  if (request.method === 'GET' && resource === 'dashboard') {
    const [projectRows, taskRows, userRows, clientRows, templateRows] = await Promise.all([
      db.select().from(projects).orderBy(desc(projects.updatedAt)).limit(20),
      db.select().from(tasks).orderBy(desc(tasks.updatedAt)).limit(40),
      db.select().from(users).orderBy(desc(users.updatedAt)).limit(20),
      db.select().from(clients).orderBy(desc(clients.updatedAt)).limit(20),
      db.select().from(workflowTemplates).orderBy(desc(workflowTemplates.updatedAt)).limit(20),
    ])

    return json({
      projects: projectRows,
      tasks: taskRows,
      users: userRows,
      clients: clientRows,
      workflowTemplates: templateRows,
      ...seedWorkspace,
    })
  }

  if (request.method === 'POST' && resource === 'project') {
    const payload = await request.json()
    const [project] = await db.insert(projects).values(payload).returning()
    return json(project, { status: 201 })
  }

  if (request.method === 'POST' && resource === 'task') {
    const payload = await request.json()
    const [task] = await db.insert(tasks).values(payload).returning()
    return json(task, { status: 201 })
  }

  if (request.method === 'PATCH' && resource === 'task') {
    const payload = await request.json()
    if (!payload.id) return json({ error: 'Task id is required' }, { status: 400 })
    const { id, ...updates } = payload
    const [task] = await db.update(tasks).set(updates).where(eq(tasks.id, id)).returning()
    return json(task)
  }

  if (request.method === 'POST' && resource === 'seed') {
    const [company] = await db.insert(companies).values({ name: 'Demo Performance Agency', timezone: 'America/New_York' }).returning()
    const [admin] = await db.insert(users).values({ companyId: company.id, email: 'super.admin@agencyos.demo', fullName: 'Maya Raval', role: 'super_admin', department: 'Operations', designation: 'Founder', status: 'online' }).returning()
    const [client] = await db.insert(clients).values({ companyId: company.id, companyName: 'Northstar Dental Group', contactPerson: 'Theo Grant', email: 'theo@northstar.example' }).returning()
    const [template] = await db.insert(workflowTemplates).values({
      companyId: company.id,
      name: 'Meta Ads Launch Workflow',
      serviceType: 'Meta Ads',
      createdById: admin.id,
      steps: [
        { title: 'Research', department: 'Paid Media', order: 1 },
        { title: 'Creative Design', department: 'Creative', order: 2 },
        { title: 'Copywriting', department: 'Content', order: 3 },
        { title: 'Campaign Setup', department: 'Paid Media', order: 4 },
        { title: 'Pixel Verification', department: 'Web', order: 5 },
        { title: 'Launch', department: 'Paid Media', order: 6 },
        { title: 'Optimization', department: 'Paid Media', order: 7 },
        { title: 'Weekly Report', department: 'Analytics', order: 8 },
        { title: 'Monthly Report', department: 'Analytics', order: 9 },
        { title: 'Completion', department: 'Operations', order: 10 },
      ],
    }).returning()
    const [project] = await db.insert(projects).values({ companyId: company.id, clientId: client.id, workflowTemplateId: template.id, name: 'Northstar Meta Ads Scale', serviceType: 'Meta Ads', budget: '38740', managerId: admin.id, priority: 'high', status: 'active', progress: 72, color: '#ff7058' }).returning()
    return json({ company, admin, client, template, project }, { status: 201 })
  }

  return json({ error: 'Not found' }, { status: 404 })
}

export const config: Config = {
  path: '/api/workspace',
}
