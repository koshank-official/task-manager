import { createFileRoute } from '@tanstack/react-router'
import type { ReactNode } from 'react'
import { useMemo, useState } from 'react'
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  LineElement,
  PointElement,
  ArcElement,
  Tooltip,
  Legend,
  Filler,
} from 'chart.js'
import { Bar, Doughnut, Line } from 'react-chartjs-2'
import {
  Archive,
  Bell,
  CalendarDays,
  CheckCircle2,
  ChevronDown,
  Clock3,
  Command,
  Files,
  Filter,
  Gauge,
  KanbanSquare,
  LayoutDashboard,
  ListTodo,
  LogIn,
  MailPlus,
  Menu,
  MessageSquare,
  Moon,
  MoreHorizontal,
  Plus,
  Search,
  Settings,
  ShieldCheck,
  Sparkles,
  Sun,
  Timer,
  Users,
  X,
  Zap,
} from 'lucide-react'

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  LineElement,
  PointElement,
  ArcElement,
  Tooltip,
  Legend,
  Filler,
)

export const Route = createFileRoute('/')({
  component: AgencyOS,
})

type Theme = 'light' | 'dark'

const roles = [
  'Super Admin',
  'Admin',
  'Project Manager',
  'Team Leader',
  'Employee',
  'Client',
]

const serviceTypes = [
  'SEO',
  'Meta Ads',
  'Google Ads',
  'Social Media',
  'Content Writing',
  'Graphic Design',
  'Video Editing',
  'Web Development',
  'Funnels',
  'Lead Generation',
  'Automation',
  'CRM',
]

const stats = [
  { label: 'Active projects', value: '38', change: '+6 this month', icon: LayoutDashboard },
  { label: "Today's tasks", value: '94', change: '17 critical', icon: ListTodo },
  { label: 'Billable hours', value: '1,284.6', change: '+12.4% WoW', icon: Timer },
  { label: 'Late tasks', value: '11', change: '-8 since Monday', icon: Clock3 },
]

const projects = [
  {
    name: 'Northstar Meta Ads Scale',
    client: 'Northstar Dental Group',
    service: 'Meta Ads',
    budget: '$38,740',
    manager: 'Maya Raval',
    progress: 72,
    priority: 'High',
    status: 'In Progress',
    color: '#ff7058',
    due: 'Jul 18',
  },
  {
    name: 'Orchid SEO Authority Sprint',
    client: 'Orchid Fintech',
    service: 'SEO',
    budget: '$21,380',
    manager: 'Elias Ward',
    progress: 48,
    priority: 'Medium',
    status: 'Review',
    color: '#27b089',
    due: 'Aug 02',
  },
  {
    name: 'PixelForge Landing Funnel',
    client: 'PixelForge Studio',
    service: 'Funnels',
    budget: '$14,920',
    manager: 'Nora Kim',
    progress: 86,
    priority: 'Critical',
    status: 'Testing',
    color: '#4f8cff',
    due: 'Jul 04',
  },
]

const kanban = [
  {
    status: 'Backlog',
    tasks: ['Competitor angle map', 'CRM field audit', 'UTM naming cleanup'],
  },
  {
    status: 'Todo',
    tasks: ['Pixel verification', 'Keyword gap clustering', 'Client approval brief'],
  },
  {
    status: 'In Progress',
    tasks: ['Campaign setup QA', 'Creative design batch 04', 'Technical audit fixes'],
  },
  {
    status: 'Review',
    tasks: ['Weekly report deck', 'Landing page copy pass'],
  },
  {
    status: 'Completed',
    tasks: ['Retargeting audience sync', 'Backlink prospect list'],
  },
]

const team = [
  { name: 'Maya Raval', role: 'Project Manager', dept: 'Paid Media', status: 'Online', hours: '36.5h', score: 94 },
  { name: 'Elias Ward', role: 'Team Leader', dept: 'SEO', status: 'Busy', hours: '41.2h', score: 88 },
  { name: 'Nora Kim', role: 'Employee', dept: 'Creative', status: 'Online', hours: '39.8h', score: 91 },
  { name: 'Theo Grant', role: 'Client', dept: 'Client Access', status: 'Offline', hours: '4.5h', score: 72 },
]

const activity = [
  'Maya assigned Pixel Verification to Aditi Sharma',
  'Northstar approved Creative Batch 04',
  'SEO template created 7 default tasks',
  'Elias requested revision on Technical Audit',
  'Nora uploaded version 3 of landing hero',
]

const nav = [
  { label: 'Dashboard', icon: LayoutDashboard },
  { label: 'Projects', icon: KanbanSquare },
  { label: 'Tasks', icon: ListTodo },
  { label: 'Calendar', icon: CalendarDays },
  { label: 'Reports', icon: Gauge },
  { label: 'Team', icon: Users },
  { label: 'Files', icon: Files },
  { label: 'Chat', icon: MessageSquare },
  { label: 'Settings', icon: Settings },
]

const monthlyThroughput = {
  labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul'],
  datasets: [
    {
      label: 'Completed',
      data: [184, 211, 236, 228, 276, 319, 347],
      borderColor: '#27b089',
      backgroundColor: 'rgba(39, 176, 137, .12)',
      fill: true,
      tension: 0.42,
      pointRadius: 3,
    },
    {
      label: 'Late',
      data: [32, 27, 41, 24, 19, 16, 11],
      borderColor: '#ff7058',
      backgroundColor: 'rgba(255, 112, 88, .08)',
      fill: true,
      tension: 0.42,
      pointRadius: 3,
    },
  ],
}

const workload = {
  labels: ['SEO', 'Paid', 'Social', 'Creative', 'Web', 'CRM'],
  datasets: [
    {
      label: 'Hours',
      data: [188, 264, 142, 219, 176, 98],
      backgroundColor: ['#27b089', '#ff7058', '#4f8cff', '#d9a441', '#8e7cc3', '#6a7f89'],
      borderRadius: 8,
    },
  ],
}

const approvalMix = {
  labels: ['Approved', 'Needs revision', 'Waiting client', 'Rejected'],
  datasets: [
    {
      data: [62, 18, 15, 5],
      backgroundColor: ['#27b089', '#d9a441', '#4f8cff', '#ff7058'],
      borderWidth: 0,
    },
  ],
}

function AgencyOS() {
  const [theme, setTheme] = useState<Theme>('dark')
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [modal, setModal] = useState<'task' | 'invite' | 'auth' | null>(null)
  const [view, setView] = useState<'Kanban' | 'List' | 'Calendar' | 'Gantt' | 'Table'>('Kanban')
  const [dragged, setDragged] = useState<string | null>(null)

  const chartOptions = useMemo(
    () => ({
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          labels: {
            color: theme === 'dark' ? '#d6dde2' : '#34454d',
            boxWidth: 10,
            usePointStyle: true,
          },
        },
      },
      scales: {
        x: { ticks: { color: theme === 'dark' ? '#9ba8ad' : '#617178' }, grid: { display: false } },
        y: { ticks: { color: theme === 'dark' ? '#9ba8ad' : '#617178' }, grid: { color: theme === 'dark' ? '#223239' : '#e4ebee' } },
      },
    }),
    [theme],
  )

  return (
    <main className={theme === 'dark' ? 'dark' : ''}>
      <div className="min-h-screen bg-stone-50 text-slate-900 transition-colors duration-300 dark:bg-[#101719] dark:text-slate-100">
        <div className="pointer-events-none fixed inset-0 bg-[radial-gradient(circle_at_20%_0%,rgba(39,176,137,.16),transparent_28%),radial-gradient(circle_at_90%_8%,rgba(255,112,88,.12),transparent_24%)]" />
        <Sidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />
        <section className="relative lg:pl-72">
          <Header
            theme={theme}
            onTheme={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
            onMenu={() => setSidebarOpen(true)}
            onTask={() => setModal('task')}
            onInvite={() => setModal('invite')}
            onAuth={() => setModal('auth')}
          />

          <div className="mx-auto max-w-[1560px] px-4 pb-10 pt-4 sm:px-6 lg:px-8">
            <section className="grid gap-4 xl:grid-cols-[1.5fr_.8fr]">
              <div className="rounded-[8px] border border-slate-200/80 bg-white/86 p-5 shadow-sm backdrop-blur dark:border-white/10 dark:bg-[#151f22]/88">
                <div className="flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between">
                  <div>
                    <p className="text-xs font-semibold uppercase tracking-[.22em] text-emerald-700 dark:text-emerald-300">Agency Command Center</p>
                    <h1 className="mt-2 max-w-3xl text-3xl font-semibold tracking-tight sm:text-4xl">Performance work, approvals, time, and client delivery in one operating system.</h1>
                    <p className="mt-3 max-w-2xl text-sm leading-6 text-slate-600 dark:text-slate-300">
                      Run SEO, paid media, creative, web, automation, and CRM projects with role-aware access, workflow templates, live notifications, and billable reporting.
                    </p>
                  </div>
                  <div className="grid min-w-64 grid-cols-2 gap-3">
                    <button onClick={() => setModal('task')} className="inline-flex items-center justify-center gap-2 rounded-[8px] bg-[#ff7058] px-4 py-3 text-sm font-semibold text-white shadow-lg shadow-red-500/20 transition hover:-translate-y-0.5">
                      <Plus className="h-4 w-4" /> Quick add
                    </button>
                    <button className="inline-flex items-center justify-center gap-2 rounded-[8px] border border-slate-200 bg-white px-4 py-3 text-sm font-semibold transition hover:-translate-y-0.5 dark:border-white/10 dark:bg-white/5">
                      <Command className="h-4 w-4" /> Command
                    </button>
                  </div>
                </div>
                <div className="mt-6 grid gap-3 md:grid-cols-2 xl:grid-cols-4">
                  {stats.map((stat) => (
                    <div key={stat.label} className="rounded-[8px] border border-slate-200 bg-slate-50 p-4 transition hover:-translate-y-1 dark:border-white/10 dark:bg-white/[.04]">
                      <div className="flex items-center justify-between">
                        <stat.icon className="h-5 w-5 text-emerald-700 dark:text-emerald-300" />
                        <span className="text-xs text-slate-500 dark:text-slate-400">{stat.change}</span>
                      </div>
                      <div className="mt-5 text-3xl font-semibold">{stat.value}</div>
                      <div className="text-sm text-slate-500 dark:text-slate-400">{stat.label}</div>
                    </div>
                  ))}
                </div>
              </div>

              <Panel title="Live Notifications" action={<Bell className="h-4 w-4" />}>
                <div className="space-y-3">
                  {activity.map((item, index) => (
                    <div key={item} className="flex gap-3 rounded-[8px] bg-slate-50 p-3 text-sm dark:bg-white/[.04]">
                      <span className="mt-1 h-2 w-2 rounded-full bg-[#27b089]" />
                      <div>
                        <p>{item}</p>
                        <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">{index + 7} min ago</p>
                      </div>
                    </div>
                  ))}
                </div>
              </Panel>
            </section>

            <section className="mt-4 grid gap-4 xl:grid-cols-[1fr_.72fr]">
              <Panel title="Project Portfolio" action={<Filter className="h-4 w-4" />}>
                <div className="grid gap-3">
                  {projects.map((project) => (
                    <article key={project.name} className="rounded-[8px] border border-slate-200 bg-white p-4 transition hover:border-[#27b089]/50 dark:border-white/10 dark:bg-[#111a1d]">
                      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                        <div className="min-w-0">
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="h-3 w-3 rounded-full" style={{ backgroundColor: project.color }} />
                            <h3 className="font-semibold">{project.name}</h3>
                            <Badge>{project.service}</Badge>
                            <Badge tone={project.priority === 'Critical' ? 'danger' : 'neutral'}>{project.priority}</Badge>
                          </div>
                          <p className="mt-2 text-sm text-slate-500 dark:text-slate-400">{project.client} / {project.manager} / due {project.due}</p>
                        </div>
                        <div className="w-full md:w-64">
                          <div className="mb-2 flex justify-between text-xs text-slate-500 dark:text-slate-400">
                            <span>{project.status}</span>
                            <span>{project.progress}%</span>
                          </div>
                          <div className="h-2 overflow-hidden rounded-full bg-slate-200 dark:bg-white/10">
                            <div className="h-full rounded-full bg-[#27b089]" style={{ width: `${project.progress}%` }} />
                          </div>
                        </div>
                      </div>
                    </article>
                  ))}
                </div>
              </Panel>

              <Panel title="Reports" action={<Archive className="h-4 w-4" />}>
                <div className="h-64">
                  <Line data={monthlyThroughput} options={chartOptions} />
                </div>
              </Panel>
            </section>

            <section className="mt-4 grid gap-4 xl:grid-cols-[1.35fr_.65fr]">
              <Panel
                title="Task Views"
                action={
                  <div className="flex rounded-[8px] bg-slate-100 p-1 text-xs dark:bg-white/5">
                    {(['Kanban', 'List', 'Calendar', 'Gantt', 'Table'] as const).map((item) => (
                      <button key={item} onClick={() => setView(item)} className={`rounded-[6px] px-3 py-1.5 ${view === item ? 'bg-white shadow-sm dark:bg-white/10' : 'text-slate-500 dark:text-slate-400'}`}>
                        {item}
                      </button>
                    ))}
                  </div>
                }
              >
                {view === 'Kanban' ? (
                  <div className="grid gap-3 overflow-x-auto pb-2 md:grid-cols-5">
                    {kanban.map((column) => (
                      <div key={column.status} className="min-w-52 rounded-[8px] bg-slate-100 p-3 dark:bg-white/[.04]" onDragOver={(event) => event.preventDefault()} onDrop={() => setDragged(null)}>
                        <div className="mb-3 flex items-center justify-between">
                          <h3 className="text-sm font-semibold">{column.status}</h3>
                          <span className="rounded-full bg-white px-2 py-0.5 text-xs dark:bg-white/10">{column.tasks.length}</span>
                        </div>
                        <div className="space-y-3">
                          {column.tasks.map((task) => (
                            <button
                              key={task}
                              draggable
                              onDragStart={() => setDragged(task)}
                              className={`w-full rounded-[8px] border border-slate-200 bg-white p-3 text-left text-sm shadow-sm transition hover:-translate-y-0.5 dark:border-white/10 dark:bg-[#121c1f] ${dragged === task ? 'opacity-50' : ''}`}
                            >
                              <div className="flex items-center justify-between gap-2">
                                <span>{task}</span>
                                <MoreHorizontal className="h-4 w-4 text-slate-400" />
                              </div>
                              <div className="mt-3 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
                                <span>2 assignees</span>
                                <span>3.5h</span>
                              </div>
                            </button>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <TaskTable />
                )}
              </Panel>

              <Panel title="Workload & Approvals" action={<ShieldCheck className="h-4 w-4" />}>
                <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-1">
                  <div className="h-56"><Bar data={workload} options={chartOptions} /></div>
                  <div className="h-56"><Doughnut data={approvalMix} options={{ responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom', labels: { color: theme === 'dark' ? '#d6dde2' : '#34454d', boxWidth: 10 } } } }} /></div>
                </div>
              </Panel>
            </section>

            <section className="mt-4 grid gap-4 lg:grid-cols-3">
              <Panel title="Team Management" action={<MailPlus className="h-4 w-4" />}>
                <div className="space-y-3">
                  {team.map((person) => (
                    <div key={person.name} className="flex items-center gap-3 rounded-[8px] bg-slate-50 p-3 dark:bg-white/[.04]">
                      <div className="grid h-10 w-10 place-items-center rounded-[8px] bg-[#27b089]/15 font-semibold text-[#166c55] dark:text-emerald-200">{person.name.split(' ').map((part) => part[0]).join('')}</div>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center justify-between gap-2">
                          <p className="truncate text-sm font-semibold">{person.name}</p>
                          <Badge tone={person.status === 'Busy' ? 'warning' : person.status === 'Online' ? 'success' : 'neutral'}>{person.status}</Badge>
                        </div>
                        <p className="text-xs text-slate-500 dark:text-slate-400">{person.role} / {person.dept} / {person.hours}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </Panel>

              <Panel title="Automation Templates" action={<Zap className="h-4 w-4" />}>
                <div className="space-y-3">
                  {['Meta Ads: Research to Monthly Report', 'SEO: Keyword Research to Completion', 'Web: Discovery to Launch QA'].map((template, index) => (
                    <div key={template} className="rounded-[8px] border border-slate-200 p-3 dark:border-white/10">
                      <p className="text-sm font-semibold">{template}</p>
                      <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">{8 + index * 3} task steps / auto-assign by department</p>
                    </div>
                  ))}
                </div>
              </Panel>

              <Panel title="Security & Access" action={<ShieldCheck className="h-4 w-4" />}>
                <div className="grid grid-cols-2 gap-2">
                  {roles.map((role) => (
                    <div key={role} className="rounded-[8px] bg-slate-50 p-3 text-sm dark:bg-white/[.04]">
                      <p className="font-semibold">{role}</p>
                      <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">Scoped permissions</p>
                    </div>
                  ))}
                </div>
              </Panel>
            </section>

            <section className="mt-4 grid gap-4 md:grid-cols-2 xl:grid-cols-4">
              {['Google Drive', 'Slack', 'Google Calendar', 'Zoom'].map((integration) => (
                <div key={integration} className="rounded-[8px] border border-slate-200 bg-white p-4 dark:border-white/10 dark:bg-[#151f22]">
                  <div className="flex items-center justify-between">
                    <p className="font-semibold">{integration}</p>
                    <Badge tone="success">Ready</Badge>
                  </div>
                  <p className="mt-2 text-sm text-slate-500 dark:text-slate-400">OAuth-ready integration slot with webhook support.</p>
                </div>
              ))}
            </section>
          </div>
        </section>

        {modal && <Modal type={modal} onClose={() => setModal(null)} />}
      </div>
    </main>
  )
}

function Header({ theme, onTheme, onMenu, onTask, onInvite, onAuth }: { theme: Theme; onTheme: () => void; onMenu: () => void; onTask: () => void; onInvite: () => void; onAuth: () => void }) {
  return (
    <header className="sticky top-0 z-30 border-b border-slate-200/80 bg-stone-50/86 backdrop-blur-xl dark:border-white/10 dark:bg-[#101719]/86">
      <div className="mx-auto flex max-w-[1560px] items-center gap-3 px-4 py-3 sm:px-6 lg:px-8">
        <button onClick={onMenu} className="rounded-[8px] border border-slate-200 p-2 lg:hidden dark:border-white/10"><Menu className="h-5 w-5" /></button>
        <div className="relative hidden flex-1 md:block">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
          <input className="w-full rounded-[8px] border border-slate-200 bg-white py-2.5 pl-10 pr-24 text-sm outline-none transition focus:border-[#27b089] dark:border-white/10 dark:bg-white/5" placeholder="Search projects, tasks, employees, clients, files" />
          <span className="absolute right-3 top-1/2 -translate-y-1/2 rounded border border-slate-200 px-2 py-0.5 text-xs text-slate-500 dark:border-white/10">⌘ K</span>
        </div>
        <button onClick={onInvite} className="hidden items-center gap-2 rounded-[8px] border border-slate-200 px-3 py-2 text-sm font-semibold md:inline-flex dark:border-white/10"><MailPlus className="h-4 w-4" /> Invite</button>
        <button onClick={onTask} className="inline-flex items-center gap-2 rounded-[8px] bg-[#27b089] px-3 py-2 text-sm font-semibold text-white"><Plus className="h-4 w-4" /> Task</button>
        <button onClick={onTheme} className="rounded-[8px] border border-slate-200 p-2 dark:border-white/10">{theme === 'dark' ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}</button>
        <button onClick={onAuth} className="rounded-[8px] border border-slate-200 p-2 dark:border-white/10"><LogIn className="h-5 w-5" /></button>
      </div>
    </header>
  )
}

function Sidebar({ open, onClose }: { open: boolean; onClose: () => void }) {
  return (
    <>
      <aside className={`fixed inset-y-0 left-0 z-40 w-72 border-r border-slate-200 bg-white p-4 transition-transform dark:border-white/10 dark:bg-[#111a1d] lg:translate-x-0 ${open ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="grid h-10 w-10 place-items-center rounded-[8px] bg-[#27b089] text-white"><Sparkles className="h-5 w-5" /></div>
            <div>
              <p className="font-semibold">AgencyOS</p>
              <p className="text-xs text-slate-500 dark:text-slate-400">Performance workspace</p>
            </div>
          </div>
          <button onClick={onClose} className="lg:hidden"><X className="h-5 w-5" /></button>
        </div>
        <nav className="mt-8 space-y-1">
          {nav.map((item, index) => (
            <button key={item.label} className={`flex w-full items-center gap-3 rounded-[8px] px-3 py-2.5 text-sm font-medium transition ${index === 0 ? 'bg-[#27b089]/12 text-[#166c55] dark:text-emerald-200' : 'text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-white/5'}`}>
              <item.icon className="h-4 w-4" /> {item.label}
            </button>
          ))}
        </nav>
        <div className="mt-8 rounded-[8px] border border-slate-200 bg-slate-50 p-4 dark:border-white/10 dark:bg-white/[.04]">
          <p className="text-sm font-semibold">Billable timer</p>
          <p className="mt-2 text-3xl font-semibold">02:18:42</p>
          <div className="mt-3 flex gap-2">
            <button className="flex-1 rounded-[8px] bg-[#ff7058] px-3 py-2 text-xs font-semibold text-white">Stop</button>
            <button className="flex-1 rounded-[8px] border border-slate-200 px-3 py-2 text-xs font-semibold dark:border-white/10">Manual</button>
          </div>
        </div>
      </aside>
      {open && <button aria-label="Close navigation" className="fixed inset-0 z-30 bg-slate-950/35 lg:hidden" onClick={onClose} />}
    </>
  )
}

function Panel({ title, action, children }: { title: string; action?: ReactNode; children: ReactNode }) {
  return (
    <section className="rounded-[8px] border border-slate-200/80 bg-white/88 p-4 shadow-sm backdrop-blur dark:border-white/10 dark:bg-[#151f22]/88">
      <div className="mb-4 flex items-center justify-between gap-3">
        <h2 className="font-semibold">{title}</h2>
        <button className="rounded-[8px] border border-slate-200 p-2 text-slate-500 dark:border-white/10 dark:text-slate-300">{action ?? <ChevronDown className="h-4 w-4" />}</button>
      </div>
      {children}
    </section>
  )
}

function Badge({ children, tone = 'neutral' }: { children: ReactNode; tone?: 'neutral' | 'success' | 'warning' | 'danger' }) {
  const tones = {
    neutral: 'bg-slate-100 text-slate-600 dark:bg-white/10 dark:text-slate-300',
    success: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-400/15 dark:text-emerald-200',
    warning: 'bg-amber-100 text-amber-800 dark:bg-amber-400/15 dark:text-amber-200',
    danger: 'bg-red-100 text-red-800 dark:bg-red-400/15 dark:text-red-200',
  }
  return <span className={`rounded-full px-2 py-0.5 text-xs font-semibold ${tones[tone]}`}>{children}</span>
}

function TaskTable() {
  const tasks = ['Creative approval', 'Weekly SEO report', 'Google Ads optimization', 'Homepage QA']
  return (
    <div className="overflow-hidden rounded-[8px] border border-slate-200 dark:border-white/10">
      {tasks.map((task, index) => (
        <div key={task} className="grid grid-cols-[1fr_auto_auto] items-center gap-3 border-b border-slate-200 p-3 text-sm last:border-b-0 dark:border-white/10">
          <span>{task}</span>
          <Badge tone={index === 0 ? 'warning' : index === 2 ? 'danger' : 'neutral'}>{index === 2 ? 'Critical' : 'Medium'}</Badge>
          <span className="text-xs text-slate-500 dark:text-slate-400">Jul {10 + index}</span>
        </div>
      ))}
    </div>
  )
}

function Modal({ type, onClose }: { type: 'task' | 'invite' | 'auth'; onClose: () => void }) {
  const isTask = type === 'task'
  const isInvite = type === 'invite'
  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-slate-950/55 p-4 backdrop-blur-sm">
      <div className="w-full max-w-2xl rounded-[8px] border border-slate-200 bg-white p-5 shadow-2xl dark:border-white/10 dark:bg-[#121c1f]">
        <div className="mb-5 flex items-center justify-between">
          <h2 className="text-lg font-semibold">{isTask ? 'Create task' : isInvite ? 'Invite team member' : 'Sign in'}</h2>
          <button onClick={onClose} className="rounded-[8px] border border-slate-200 p-2 dark:border-white/10"><X className="h-4 w-4" /></button>
        </div>
        {isTask ? (
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="Task name" placeholder="Campaign setup QA" />
            <Field label="Project" placeholder="Northstar Meta Ads Scale" />
            <Field label="Priority" placeholder="Critical" />
            <Field label="Estimated hours" placeholder="6.5" />
            <label className="sm:col-span-2 text-sm font-medium">Description<textarea className="mt-1 min-h-24 w-full rounded-[8px] border border-slate-200 bg-transparent p-3 outline-none focus:border-[#27b089] dark:border-white/10" placeholder="Add checklist, dependencies, mentions, custom fields, and approval requirements." /></label>
          </div>
        ) : isInvite ? (
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="Email" placeholder="teammate@agency.com" />
            <Field label="Role" placeholder="Team Leader" />
            <Field label="Department" placeholder="SEO" />
            <Field label="Designation" placeholder="Senior Strategist" />
          </div>
        ) : (
          <div className="grid gap-3">
            <button className="rounded-[8px] border border-slate-200 px-4 py-3 font-semibold dark:border-white/10">Continue with Google</button>
            <Field label="Email" placeholder="admin@agency.com" />
            <Field label="Password" placeholder="••••••••" />
            <button className="text-left text-sm text-[#166c55] dark:text-emerald-300">Forgot password?</button>
          </div>
        )}
        <div className="mt-5 flex justify-end gap-2">
          <button onClick={onClose} className="rounded-[8px] border border-slate-200 px-4 py-2 text-sm font-semibold dark:border-white/10">Cancel</button>
          <button onClick={onClose} className="rounded-[8px] bg-[#27b089] px-4 py-2 text-sm font-semibold text-white">{isTask ? 'Create task' : isInvite ? 'Send invite' : 'Login'}</button>
        </div>
      </div>
    </div>
  )
}

function Field({ label, placeholder }: { label: string; placeholder: string }) {
  return (
    <label className="text-sm font-medium">
      {label}
      <input className="mt-1 w-full rounded-[8px] border border-slate-200 bg-transparent px-3 py-2.5 outline-none focus:border-[#27b089] dark:border-white/10" placeholder={placeholder} />
    </label>
  )
}
